(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const API = window.ZEROX_API || "";
  const TOKEN_KEY = "zerox_site_token";

  let token = localStorage.getItem(TOKEN_KEY) || "";
  let me = null;
  let authMode = "player";
  let modalAction = null;

  const nf = new Intl.NumberFormat("tr-TR", { maximumFractionDigits: 0 });
  const money = (value) => `${nf.format(Math.max(0, Math.round(Number(value) || 0)))} TL`;

  // ---------- yıldız alanı ----------
  const canvas = $("stars");
  if (canvas) {
    const ctx = canvas.getContext("2d");
    let stars = [];
    let width = 0;
    let height = 0;
    const resize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      stars = Array.from({ length: Math.min(150, Math.floor(width * height / 14000)) }, () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        r: Math.random() * 1.4 + 0.3,
        a: Math.random() * 0.65 + 0.12,
        s: Math.random() * 0.16 + 0.02
      }));
    };
    const draw = () => {
      ctx.clearRect(0, 0, width, height);
      for (const star of stars) {
        star.y -= star.s;
        if (star.y < -2) {
          star.y = height + 2;
          star.x = Math.random() * width;
        }
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(180, 220, 255, ${star.a})`;
        ctx.fill();
      }
      requestAnimationFrame(draw);
    };
    resize();
    window.addEventListener("resize", resize);
    if (!window.matchMedia("(prefers-reduced-motion: reduce)").matches) draw();
  }

  // ---------- toast / modal ----------
  let toastTimer = 0;
  const toast = (message, error = false) => {
    const el = $("toast");
    el.textContent = message;
    el.classList.toggle("err", error);
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("show"), 3600);
  };

  const showModal = (title, text, confirmLabel, action) => {
    $("modalTitle").textContent = title;
    $("modalText").innerHTML = text;
    $("modalConfirm").textContent = confirmLabel;
    modalAction = action;
    $("buyModal").classList.remove("hidden");
  };
  const hideModal = () => {
    $("buyModal").classList.add("hidden");
    modalAction = null;
  };
  $("modalCancel").addEventListener("click", hideModal);
  $("modalConfirm").addEventListener("click", async () => {
    if (modalAction) {
      const action = modalAction;
      hideModal();
      await action();
    }
  });
  $("buyModal").addEventListener("click", (event) => {
    if (event.target === $("buyModal")) hideModal();
  });

  const copy = async (text, message = "Kopyalandı") => {
    try {
      await navigator.clipboard.writeText(text);
      toast(message);
    } catch {
      const area = document.createElement("textarea");
      area.value = text;
      document.body.appendChild(area);
      area.select();
      document.execCommand("copy");
      area.remove();
      toast(message);
    }
  };

  // ---------- API ----------
  const request = async (path, options = {}) => {
    const headers = { ...(options.headers || {}) };
    if (token) headers["X-Token"] = token;
    if (options.body && !headers["Content-Type"]) headers["Content-Type"] = "application/json";
    let res;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 12000);
    try {
      res = await fetch(`${API}${path}`, { ...options, headers, cache: "no-store", signal: controller.signal });
    } catch (error) {
      if (error && error.name === "AbortError") {
        throw new Error("Sunucu yanıt vermedi. Sayfayı yenileyip tekrar dene.");
      }
      throw new Error("Sunucuya ulaşılamadı. Siteyi sunucunun /panel adresinden aç (örn. http://127.0.0.1:8765/panel).");
    } finally {
      clearTimeout(timer);
    }
    let data;
    try {
      data = await res.json();
    } catch {
      throw new Error("Sunucu yanıtı okunamadı.");
    }
    if (res.status === 401) {
      logout(false);
      throw new Error("Oturum süresi doldu, tekrar giriş yap.");
    }
    if (!data.ok) {
      throw new Error(data.reason || "İşlem başarısız.");
    }
    return data;
  };

  const reasonText = (reason) => {
    switch (reason) {
      case "bad-login": return "İsim veya şifre yanlış. Hesabın yoksa launcher'da Kayıt Ol ile oluştur.";
      case "auth": return "Giriş yapmalısın.";
      case "invalid": return "Geçersiz kod.";
      case "used": return "Bu kod daha önce kullanıldı.";
      case "not-owner": return "Bu kod başka bir hesaba ait. Kodu aldığın hesapla giriş yaptığından emin ol.";
      case "not-quest": return "Bu bir TL kodu. TL kodlarını oyunda /code <kod> ile kullan.";
      case "not-enough-coins": return "Yeterli coin'in yok.";
      case "bad-product": return "Geçersiz paket.";
      case "contact-required": return "İletişim bilgisi gerekli.";
      default: return "İşlem başarısız. Tekrar dene.";
    }
  };

  // ---------- auth ----------
  const setAuthMode = (mode) => {
    authMode = mode;
    document.querySelectorAll(".auth-tab").forEach((tab) => {
      tab.classList.toggle("active", tab.dataset.tab === mode);
    });
    $("nameLabel").textContent = mode === "admin" ? "Admin Kullanıcı Adı" : "Minecraft Adı";
    $("loginName").placeholder = mode === "admin" ? "zx_owner_..." : "OyuncuAdi";
    $("loginError").textContent = "";
  };

  document.querySelectorAll(".auth-tab").forEach((tab) => {
    tab.addEventListener("click", () => setAuthMode(tab.dataset.tab));
  });

  // Giris basarili olur olmaz paneli/menüyü göster; veriler arkadan dolar.
  // Böylece yavaş /me isteğinde ekranda "hiçbir şey olmuyor" görüntüsü kalmaz.
  const enterDashboard = (name, admin) => {
    $("authWrap").classList.add("hidden");
    $("dash").classList.remove("hidden");
    $("logoutBtn").classList.remove("hidden");
    $("userName").textContent = name || "…";
    $("welcomeName").textContent = name || "…";
    $("avatar").textContent = (name || "Z").charAt(0).toUpperCase();
    $("userRole").textContent = admin ? "Yönetici" : "Oyuncu";
    document.querySelectorAll(".admin-only").forEach((el) => {
      el.classList.toggle("hidden", !admin);
    });
  };

  $("loginForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const button = $("loginBtn");
    const error = $("loginError");
    const name = $("loginName").value.trim();
    const password = $("loginPassword").value;
    error.textContent = "";
    button.disabled = true;
    button.textContent = "Giriş yapılıyor…";
    try {
      let data;
      try {
        const path = authMode === "admin" ? "/api/site/admin/login" : "/api/site/login";
        data = await request(path, {
          method: "POST",
          body: JSON.stringify({ name, password })
        });
      } catch (first) {
        // Admin bilgileri yanlışlıkla oyuncu sekmesine yazıldıysa da giriş yapılabilsin.
        if (authMode === "player" && first.message === "bad-login") {
          try {
            data = await request("/api/site/admin/login", {
              method: "POST",
              body: JSON.stringify({ name, password })
            });
          } catch {
            throw first;
          }
        } else {
          throw first;
        }
      }
      token = data.token;
      localStorage.setItem(TOKEN_KEY, token);
      $("loginPassword").value = "";
      enterDashboard(data.name, data.admin);
      showView("overview", false);
      window.scrollTo({ top: 0, behavior: "smooth" });
      try {
        await loadMe();
      } catch (exception) {
        toast(exception.message, true);
      }
    } catch (exception) {
      error.textContent = exception.message === "bad-login" ? reasonText("bad-login") : exception.message;
      error.scrollIntoView({ block: "nearest", behavior: "smooth" });
    } finally {
      button.disabled = false;
      button.textContent = "Giriş Yap";
    }
  });

  const logout = (notify = true) => {
    token = "";
    me = null;
    localStorage.removeItem(TOKEN_KEY);
    $("dash").classList.add("hidden");
    $("authWrap").classList.remove("hidden");
    $("logoutBtn").classList.add("hidden");
    if (notify) toast("Çıkış yapıldı.");
  };
  $("logoutBtn").addEventListener("click", () => logout());

  // ---------- yükleme ----------
  const loadMe = async () => {
    if (!token) return;
    const data = await request("/api/site/me");
    me = data;
    $("authWrap").classList.add("hidden");
    $("dash").classList.remove("hidden");
    $("logoutBtn").classList.remove("hidden");
    $("userName").textContent = data.name;
    $("welcomeName").textContent = data.name;
    $("avatar").textContent = (data.name || "Z").charAt(0).toUpperCase();
    $("userRole").textContent = data.admin ? "Yönetici" : "Oyuncu";
    $("statCoins").textContent = nf.format(data.coins);
    $("statTl").textContent = money(data.balance);
    $("statEarned").textContent = `${data.earned} / ${data.dailyCap}`;
    $("statStatus").textContent = "Aktif";
    $("shopCoins").textContent = nf.format(data.coins);
    document.querySelectorAll(".admin-only").forEach((el) => {
      el.classList.toggle("hidden", !data.admin);
    });
    if (data.admin) {
      $("view-admin").classList.add("hidden");
    }
    renderInventory(data.inventory || []);
    if (data.admin) loadAdmin();
    applyHashView();
  };

  const refreshMe = async () => {
    if (!token) return;
    try {
      await loadMe();
    } catch (exception) {
      toast(exception.message, true);
    }
  };

  // ---------- view geçişleri ----------
  const showView = (view, updateHash = true) => {
    if (view === "admin" && !(me && me.admin)) view = "overview";
    document.querySelectorAll(".view").forEach((el) => el.classList.add("hidden"));
    const target = $(`view-${view}`);
    if (target) target.classList.remove("hidden");
    document.querySelectorAll(".dash-link").forEach((link) => {
      link.classList.toggle("active", link.dataset.view === view);
    });
    if (updateHash && location.hash !== `#${view}`) {
      history.replaceState(null, "", `#${view}`);
    }
    if (view === "inventory") refreshInventory();
    if (view === "admin") loadAdmin();
  };

  const applyHashView = () => {
    const raw = (location.hash || "").replace(/^#/, "").toLowerCase();
    if (!raw || !$(`view-${raw}`)) return;
    showView(raw, false);
  };

  window.addEventListener("hashchange", () => {
    if (me) applyHashView();
  });

  document.querySelectorAll(".dash-link").forEach((link) => {
    link.addEventListener("click", () => showView(link.dataset.view));
  });
  document.querySelectorAll("[data-go]").forEach((button) => {
    button.addEventListener("click", () => showView(button.dataset.go));
  });

  // ---------- görev kodu ----------
  $("redeemForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const note = $("redeemNote");
    const code = $("redeemCode").value.trim().toUpperCase();
    if (!code) return;
    if (code.startsWith("TL-")) {
      note.innerHTML = `Bu bir <b>TL kodu</b>, görev kodu değil. Bu kodu oyunda <code>/code ${code}</code> olarak kullan.`;
      note.className = "form-note";
      return;
    }
    note.textContent = "Kontrol ediliyor…";
    note.className = "form-note";
    try {
      const data = await request("/api/site/redeem", {
        method: "POST",
        body: JSON.stringify({ code })
      });
      note.textContent = `Kod kullanıldı: +${data.coins} coin. Yeni bakiyen: ${nf.format(data.balance)} coin.`;
      note.className = "form-note ok";
      $("redeemCode").value = "";
      toast(`Görev kodu kullanıldı: +${data.coins} coin`);
      await refreshMe();
    } catch (exception) {
      note.textContent = reasonText(exception.message);
      note.className = "form-note err";
    }
  });

  // ---------- mağaza ----------
  const products = {
    tl10k: { name: "10.000 TL Paketi", coins: 30, money: 10000 },
    tl30k: { name: "30.000 TL Paketi", coins: 50, money: 30000 },
    tl100k: { name: "100.000 TL Paketi", coins: 100, money: 100000 }
  };

  document.querySelectorAll(".buy-btn").forEach((button) => {
    button.addEventListener("click", () => {
      const productId = button.closest("[data-product]").dataset.product;
      const product = products[productId];
      if (!product) return;
      if (!me) {
        toast("Önce giriş yap.", true);
        return;
      }
      if (me.coins < product.coins) {
        toast(`Yeterli coin'in yok. Gerekli: ${product.coins} coin`, true);
        return;
      }
      showModal(
        "Satın alımı onayla",
        `<b>${product.name}</b><br>${product.coins} coin karşılığında <b>${money(product.money)}</b> değerinde kod alacaksın.`,
        "Onayla",
        async () => {
          try {
            const data = await request("/api/site/buy", {
              method: "POST",
              body: JSON.stringify({ product: productId })
            });
            await copy(data.code, `Ödeme başarılı! Kod kopyalandı: ${data.code}`);
            toast(`Ödeme başarılı • ${data.code}`);
            await refreshMe();
            showView("inventory");
          } catch (exception) {
            toast(reasonText(exception.message), true);
            await refreshMe();
          }
        }
      );
    });
  });

  // ---------- envanter ----------
  const renderInventory = (items) => {
    const list = $("inventoryList");
    if (!items || items.length === 0) {
      list.innerHTML = '<div class="empty">Henüz bir satın alma yok. Mağazadan TL paketi alabilirsin.</div>';
      return;
    }
    list.innerHTML = "";
    for (const item of items) {
      const row = document.createElement("article");
      row.className = `inv-item${item.used ? " used" : ""}`;
      const label = products[item.product]?.name || `${nf.format(item.money)} TL Paketi`;
      const date = item.created ? new Date(item.created).toLocaleString("tr-TR") : "";
      row.innerHTML = `
        <div class="inv-main">
          <strong>${label}</strong>
          <span>${money(item.money)} • ${date} • ${item.used ? "Kullanıldı" : "Kullanılmadı"}</span>
        </div>
        <code class="inv-code">${item.code}</code>
        <button class="btn btn-ghost" type="button">Kopyala</button>
      `;
      row.querySelector("button").addEventListener("click", () => copy(item.code, `Kod kopyalandı: ${item.code}`));
      list.appendChild(row);
    }
  };

  const refreshInventory = async () => {
    if (!token) return;
    try {
      const data = await request("/api/site/inventory");
      renderInventory(data.items);
    } catch (exception) {
      toast(exception.message, true);
    }
  };
  $("refreshInventory").addEventListener("click", refreshInventory);

  // ---------- admin ----------
  const loadAdmin = async () => {
    if (!me || !me.admin) return;
    try {
      const [overview, users] = await Promise.all([
        request("/api/site/admin/overview"),
        request("/api/site/admin/users")
      ]);
      $("adminUsers").textContent = nf.format(overview.users);
      $("adminCoins").textContent = nf.format(overview.totalCoins);
      $("adminCodes").textContent = nf.format(overview.purchaseCodes);
      $("adminWaitlist").textContent = nf.format(overview.waitlist);

      const body = $("adminUserRows");
      if (!users.users.length) {
        body.innerHTML = '<tr><td colspan="4" class="empty">Kayıtlı kullanıcı yok.</td></tr>';
        return;
      }
      body.innerHTML = users.users.map((user) => `
        <tr>
          <td>${user.name}${user.admin ? " ★" : ""}</td>
          <td class="gold">${nf.format(user.coins)}</td>
          <td>${nf.format(user.earned)}</td>
          <td>${money(user.balance)}</td>
        </tr>
      `).join("");
    } catch (exception) {
      toast(exception.message, true);
    }
  };

  $("grantForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const note = $("grantNote");
    note.textContent = "Gönderiliyor…";
    note.className = "form-note";
    try {
      const data = await request("/api/site/admin/grant", {
        method: "POST",
        body: JSON.stringify({
          name: $("grantName").value.trim(),
          coins: Number($("grantCoins").value)
        })
      });
      note.textContent = `${data.name} hesabına coin eklendi. Yeni bakiye: ${nf.format(data.coins)}.`;
      note.className = "form-note ok";
      $("grantCoins").value = "";
      toast("Coin gönderildi.");
      await loadAdmin();
    } catch (exception) {
      note.textContent = exception.message;
      note.className = "form-note err";
    }
  });

  // ---------- başlangıç ----------
  if (token) {
    // Menüyü hemen göster; oturum geçersizse loadMe -> logout ile geri kapanır.
    enterDashboard("", false);
    loadMe().catch(() => {
      logout(false);
    });
  }
  setAuthMode("player");
})();
