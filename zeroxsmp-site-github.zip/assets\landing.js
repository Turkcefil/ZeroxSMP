(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const API = window.ZEROX_API || "";

  // ---------- yıldız alanı ----------
  const canvas = $("stars");
  if (canvas) {
    const ctx = canvas.getContext("2d");
    let stars = [];
    let width = 0;
    let height = 0;
    let raf = 0;

    const resize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      const count = Math.min(180, Math.floor((width * height) / 12000));
      stars = Array.from({ length: count }, () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        r: Math.random() * 1.5 + 0.3,
        a: Math.random() * 0.7 + 0.15,
        s: Math.random() * 0.18 + 0.03
      }));
    };

    const draw = () => {
      ctx.clearRect(0, 0, width, height);
      for (const star of stars) {
        star.y -= star.s;
        if (star.y < -2) {
          star.y = height + 2;
          star.x = Math.random() * width;
        }
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(180, 220, 255, ${star.a})`;
        ctx.fill();
      }
      raf = requestAnimationFrame(draw);
    };

    resize();
    window.addEventListener("resize", resize);
    if (!window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      draw();
    }
    window.addEventListener("beforeunload", () => cancelAnimationFrame(raf));
  }

  // ---------- reveal ----------
  const reveal = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      }
    }, { threshold: 0.12 });
    reveal.forEach((el) => observer.observe(el));
  } else {
    reveal.forEach((el) => el.classList.add("visible"));
  }

  // ---------- toast ----------
  let toastTimer = 0;
  const toast = (message, error = false) => {
    const el = $("toast");
    if (!el) return;
    el.textContent = message;
    el.classList.toggle("err", error);
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("show"), 3200);
  };

  // ---------- sunucu durumu ----------
  const loadStatus = async () => {
    try {
      const res = await fetch(`${API}/api/site/status`, { cache: "no-store" });
      const data = await res.json();
      if (!data.ok) throw new Error("status");
      $("onlineCount").textContent = data.online;
      $("tpsCount").textContent = Number(data.tps).toFixed(1).replace(".", ",");
      $("statusText").textContent = `${data.online}/${data.max} oyuncu • ${Number(data.tps).toFixed(1)} TPS`;
    } catch {
      $("onlineCount").textContent = "—";
      $("tpsCount").textContent = "—";
      $("statusText").textContent = "Sunucu durumu alınamadı";
      $("statusDot").style.background = "#fb7185";
    }
  };
  if ($("onlineCount")) {
    loadStatus();
    setInterval(loadStatus, 30000);
  }

  // ---------- IP kopyala ----------
  const copyText = async (text, message) => {
    try {
      await navigator.clipboard.writeText(text);
      toast(message);
    } catch {
      const area = document.createElement("textarea");
      area.value = text;
      document.body.appendChild(area);
      area.select();
      document.execCommand("copy");
      area.remove();
      toast(message);
    }
  };

  if ($("ipChip")) {
    $("ipChip").addEventListener("click", () => copyText("oyna.zerox.com", "IP kopyalandı: oyna.zerox.com"));
  }
  if ($("copyIp")) {
    $("copyIp").addEventListener("click", () => copyText("oyna.zerox.com", "IP kopyalandı: oyna.zerox.com"));
  }

  // ---------- mobil menü ----------
  if ($("navBurger")) {
    $("navBurger").addEventListener("click", () => $("navLinks").classList.toggle("open"));
    document.querySelectorAll("#navLinks a").forEach((link) => {
      link.addEventListener("click", () => $("navLinks").classList.remove("open"));
    });
  }

  // ---------- android bekleme listesi ----------
  if ($("waitlistForm")) {
    $("waitlistForm").addEventListener("submit", async (event) => {
      event.preventDefault();
      const input = $("waitlistContact");
      const note = $("waitlistNote");
      const contact = input.value.trim();
      if (contact.length < 3) {
        note.textContent = "Geçerli bir e-posta veya telefon gir.";
        note.className = "form-note err";
        return;
      }
      note.textContent = "Kaydediliyor…";
      note.className = "form-note";
      try {
        const res = await fetch(`${API}/api/site/waitlist`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ contact, platform: "android" })
        });
        const data = await res.json();
        if (!data.ok) throw new Error(data.reason || "hata");
        note.textContent = "Listeye eklendin! Android sürümü çıkınca haber vereceğiz.";
        note.className = "form-note ok";
        input.value = "";
        toast("Android bekleme listesine eklendin.");
      } catch {
        note.textContent = "Şu anda kaydedilemedi. Biraz sonra tekrar dene.";
        note.className = "form-note err";
      }
    });
  }
})();
