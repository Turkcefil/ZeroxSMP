# ZeroxSMP GitHub Pages Paketi

Bu klasör, GitHub Pages'e **doğrudan yüklenebilecek** küçük sürümdür.
İçinde 66 MB'lık `ZeroxLauncher.exe` yoktur; launcher indirme butonu çalışan
Cloudflare Tunnel adresine gider.

## GitHub Pages'e yükleme

1. GitHub'da **public** bir repo oluştur (ör. `zeroxsmp-site`).
2. Bu klasördeki tüm dosyaları repo köküne yükle.
3. **Settings → Pages → Deploy from a branch → main / root** seç.
4. Yayın adresi: `https://<kullanıcı>.github.io/zeroxsmp-site/`

## Canlı adres

- Ana sayfa: https://hiring-english-role-rounds.trycloudflare.com/
- Panel: https://hiring-english-role-rounds.trycloudflare.com/panel
- Launcher: https://hiring-english-role-rounds.trycloudflare.com/download/launcher

Panel, GitHub Pages'te statik dosya olarak açılır; giriş/coin/TL işlemleri
`assets/config.js` içindeki tunnel adresine gider. Tunnel kapanırsa panel
veri çekemez; ana sayfa ve launcher indirme çalışmaya devam eder.

Tunnel adresi değişirse `assets/config.js` içindeki `window.ZEROX_API`
satırını güncelle.

## Tam paket

Launcher dahil tam klasör: `..\zeroxsmp-site\`
