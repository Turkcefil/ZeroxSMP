/*
 * ZeroxSMP public site API adresi.
 *
 * Yerelde (127.0.0.1 / localhost) API ayni sunucudadir; GitHub Pages gibi
 * statik bir alan adinda ise canli panel/API Cloudflare Tunnel uzerinden
 * calisir. Tunnel adresi degisirse sadece asagidaki satiri guncelle.
 */
(() => {
  const host = location.hostname;
  const local = host === "127.0.0.1" || host === "localhost" || host === "";
  window.ZEROX_API = local ? "" : "https://hiring-english-role-rounds.trycloudflare.com";
})();
